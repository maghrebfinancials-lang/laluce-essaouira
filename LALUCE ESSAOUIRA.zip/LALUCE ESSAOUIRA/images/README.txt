LALUCE ESSAOUIRA — Images Folder
=================================

Place your image files here with the following names:

REQUIRED IMAGES:
  hero.jpg          — Full-screen hero (1920x1080 min, landscape, Essaouira / Atlantic view)
  room1.jpg         — Suite Bleue Impériale (800x600)
  room2.jpg         — Chambre Safran (800x600)
  room3.jpg         — Chambre Rose des Sables (800x600)
  yoga.jpg          — Yoga shala or ocean yoga (900x600)
  yoga-accent.jpg   — Close-up meditation / hands (400x500)
  cooking.jpg       — Moroccan cooking class (900x600)
  cooking-bg.jpg    — Background texture for cooking section
  story1.jpg        — Essaouira medina / ramparts (900x400)
  story2.jpg        — Moroccan crafts / zellige (600x300)
  story3.jpg        — Riad architecture (600x300)
  cta-bg.jpg        — Background for CTA banner
  og-image.jpg      — Open Graph / social preview (1200x630)

NOTES:
- Optimize all images: use webp format for best performance
- Keep file sizes under 300KB each
- Use descriptive alt text (already included in HTML)

CURRENTLY:
  The website uses Unsplash CDN images as placeholders.
  Replace src attributes in index.html to point to your local images
  once you have them ready.
